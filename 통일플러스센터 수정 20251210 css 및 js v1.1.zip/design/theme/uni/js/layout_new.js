$(document).ready(function () {
  "use strict";
  // script start

  // .gnb
  $(document).on('mouseover focus', '.gnb .btn-depth1', function () {
    if ($(this).siblings().hasClass('gnb-depth2')) { // 하위 메뉴가 있을 때
      $(this).next('.gnb-depth2').show().parent().siblings().find('.gnb-depth2').hide();
    }
  });
  $(document).on('mouseover focus', '.gnb-close', function () {
    $('.gnb .gnb-depth2').hide();
  });
  $(document).on('mouseleave', '.header', function () {
    $('.gnb .gnb-depth2').hide();
  });

  // .gnb-all
  $(document).on('click', '.header .btn-allmenu', function () {
    $('.gnb-all-wrap').addClass('open');
    $('.header .btn-close').focus();
  });
  $(document).on('click', '.header .btn-close', function () {
    $('.gnb-all-wrap').removeClass('open');
    $('.header .btn-allmenu').focus();
  });
  $(document).on('click', '.gnb-all-wrap button.btn-depth1', function () {
    if ($(this).parent().hasClass('open')) {
      $(this).next().slideUp('100').parent().removeClass('open');
    } else {
      $(this).next().slideDown('100').parent().addClass('open').siblings().removeClass('open').find('.gnb-depth2').slideUp('100');
    }
  });
  $(document).on('focus', '.gnb-all-wrap .gnb-back', function () {
    $('.header .btn-close').focus();
  });

  // slide
  if ($('.main-slider-01').length > 0) { // 25
    var slideTotal = $('.main-slider-01 .swiper-slide').length;
    var slideTotalH = slideTotal / 2;
    var swiperMain01 = new Swiper(".main-slider-01", {
      slidesPerView: 2,
      spaceBetween: 10,
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
      navigation: {
        nextEl: ".main-center .btn-next",
        prevEl: ".main-center .btn-prev"
      },
      on: {
        init: function () {
          $('.main-center .swiper-slide').addClass('changed');
          $('.main-center .custom-fraction .current').text(this.realIndex + 1);
          $('.main-center .custom-fraction .all').text(slideTotalH);
        },
        slideChangeTransitionStart: function () {
          $('.main-center .swiper-slide').addClass('changing');
          $('.main-center .swiper-slide').removeClass('changed');
          // $('.main-center .custom-fraction .current').text(this.realIndex + 1);
          // 반복슬라이드로 인한 넘버링 컨트롤 250714
          var slideCText = $('.main-slider-01 .swiper-slide.swiper-slide-active').attr('data-swiper-slide-index');
          var slideCNum = parseInt(slideCText);
          var slideCN02 = slideCNum + 1;
          if (slideCN02 > slideTotalH) {
            slideCN02 = slideCN02 - slideTotalH;
          }
          $('.main-center .custom-fraction .current').text(slideCN02);
        },
        slideChangeTransitionEnd: function () {
          $('.main-center .swiper-slide').removeClass('changing');
          $('.main-center .swiper-slide').addClass('changed');
        }
      },
    });
  }
  $(".main-center .btn-start").on("click", function () {
    swiperMain01.autoplay.start();
    $(this).removeClass('active').next('.btn-stop').addClass('active');
  });
  $(".main-center .btn-stop").on("click", function () {
    swiperMain01.autoplay.stop();
    $(this).removeClass('active').prev('.btn-start').addClass('active');
  });
  $('.swiper-slide').hover(function () {
    swiperMain01.autoplay.stop();
  }, function () {
    swiperMain01.autoplay.start();
  });
  $('.swiper-slide a').focus(function () {
    swiperMain01.autoplay.stop();
  }, function () {
    swiperMain01.autoplay.start();
  });
  $(document).on('mouseover', '.main-center .swiper-slide .page01', function () {
    $(this).parent().addClass('hover').siblings().removeClass('hover');
  });
  $(document).on('mouseleave', '.main-center .swiper-slide', function () { // 250910 추가
    $(this).removeClass('hover');
  });
  $(document).on('focus', '.main-center .swiper-slide .page02 a', function () {
    $(this).parents('.swiper-slide').addClass('hover').siblings().removeClass('hover');
  });

  // tab
  $(document).on('click', '.tab-wrap .tab-head .btn', function (e) {
    e.preventDefault();
    var target = $(this).attr('href');
    $(this).addClass('active').parent().siblings().find('.btn').removeClass('active');
    // 20251210 의미 없는 포커스 이동 하면 안됨 수정
    // ✅ 새로 활성화된 패널 안에서 첫 포커스 가능한 요소를 찾는다
    var $panel = $(target).addClass('active').siblings().removeClass('active');
    // $(target).find('.tab-title').focus();
    // ✅ 새로 활성화된 패널 안에서 첫 포커스 가능한 요소를 찾는다
    var $firstFocusable = $panel.find('a, button, input, select, textarea, [tabindex]:not([tabindex="-1"])').first();

    if ($firstFocusable.length) {
      $firstFocusable.focus();
    }
    if ($(this).parent().parent().parent().hasClass('tab-map')) {
      $(this).parent().parent().removeClass('active-su active-ggd active-dg active-cb active-cn active-gb active-gn active-jb active-jn active-gwd active-jjd active-ic active-bs active-us active-dj active-gj')
      if ($(this).hasClass('ggd')) {
        $(this).parent().parent().addClass('active-ggd');
      } else if ($(this).hasClass('dg')) {
        $(this).parent().parent().addClass('active-dg');
      } else if ($(this).hasClass('cb')) {
        $(this).parent().parent().addClass('active-cb');
      } else if ($(this).hasClass('cn')) {
        $(this).parent().parent().addClass('active-cn');
      } else if ($(this).hasClass('gb')) {
        $(this).parent().parent().addClass('active-gb');
      } else if ($(this).hasClass('gn')) {
        $(this).parent().parent().addClass('active-gn');
      } else if ($(this).hasClass('jb')) {
        $(this).parent().parent().addClass('active-jb');
      } else if ($(this).hasClass('jn')) {
        $(this).parent().parent().addClass('active-jn');
      } else if ($(this).hasClass('gwd')) {
        $(this).parent().parent().addClass('active-gwd');
      } else if ($(this).hasClass('jjd')) {
        $(this).parent().parent().addClass('active-jjd');
      } else if ($(this).hasClass('su')) {
        $(this).parent().parent().addClass('active-su');
      } else if ($(this).hasClass('ic')) {
        $(this).parent().parent().addClass('active-ic');
      } else if ($(this).hasClass('bs')) {
        $(this).parent().parent().addClass('active-bs');
      } else if ($(this).hasClass('us')) {
        $(this).parent().parent().addClass('active-us');
      } else if ($(this).hasClass('dj')) {
        $(this).parent().parent().addClass('active-dj');
      } else if ($(this).hasClass('gj')) {
        $(this).parent().parent().addClass('active-gj');
      }
    }
  });
  $(document).on('mouseover focus', '.tab-map .btn', function (e) {
    e.preventDefault();
    if ($(this).parent().parent().parent().hasClass('tab-map')) {
      $(this).parent().parent().removeClass('su ggd dg cb cn gb gn jb jn gwd jjd ic bs us dj gj');
      if ($(this).hasClass('ggd')) {
        $(this).parent().parent().addClass('ggd');
      } else if ($(this).hasClass('dg')) {
        $(this).parent().parent().addClass('dg');
      } else if ($(this).hasClass('cb')) {
        $(this).parent().parent().addClass('cb');
      } else if ($(this).hasClass('cn')) {
        $(this).parent().parent().addClass('cn');
      } else if ($(this).hasClass('gb')) {
        $(this).parent().parent().addClass('gb');
      } else if ($(this).hasClass('gn')) {
        $(this).parent().parent().addClass('gn');
      } else if ($(this).hasClass('jb')) {
        $(this).parent().parent().addClass('jb');
      } else if ($(this).hasClass('jn')) {
        $(this).parent().parent().addClass('jn');
      } else if ($(this).hasClass('gwd')) {
        $(this).parent().parent().addClass('gwd');
      } else if ($(this).hasClass('jjd')) {
        $(this).parent().parent().addClass('jjd');
      } else if ($(this).hasClass('su')) {
        $(this).parent().parent().addClass('su');
      } else if ($(this).hasClass('bs')) {
        $(this).parent().parent().addClass('bs');
      } else if ($(this).hasClass('ic')) {
        $(this).parent().parent().addClass('ic');
      } else if ($(this).hasClass('dj')) {
        $(this).parent().parent().addClass('dj');
      } else if ($(this).hasClass('us')) {
        $(this).parent().parent().addClass('us');
      } else if ($(this).hasClass('gj')) {
        $(this).parent().parent().addClass('gj');
      }
    }
  });
  $(document).on('mouseleave', '.tab-map .btn', function (e) {
    $(this).parent().parent().removeClass('su ggd dg cb cn gb gn jb jn gwd jjd bs ic dj us gj');
  });
  $(document).on('click', '.tab-style-01 .btn-allcenter', function (e) {
    e.preventDefault();
    $('.tab-style-01 .tab-head ul').removeClass('active-su active-ggd active-dg active-cb active-cn active-gb active-gn active-jb active-jn active-gwd active-jjd active-ic active-bs active-us active-dj active-gj')
    $('.tab-style-01 .tab-head .btn').removeClass('active');
    $('.tab-style-01 .tab-con').removeClass('active');
    $('.tab-style-01 .tab-con#tabMall00').addClass('active');
    // 20251210 의미 없는 포커스 이동 하면 안됨 추가
    var $panel = $('.tab-style-01 .tab-con#tabMall00').addClass('active');
    var $firstFocusable = $panel.find('a, button, input, select, textarea, [tabindex]:not([tabindex="-1"])').first();
    if ($firstFocusable.length) {
      $firstFocusable.focus();
    }

  });

});